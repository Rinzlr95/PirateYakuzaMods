#ifndef AFFIX_SETTINGS_PANEL_H
#define AFFIX_SETTINGS_PANEL_H
#include <commctrl.h>
// Native Win32 panel: no graphics-device injection. F8 opens it while the
// game is focused; F7 toggles health numbers. Borderless/windowed recommended.
typedef struct PanelSetting {const char *key;double *value,low,high,step;int page;} PanelSetting;
static PanelSetting panelSettings[]={
 {"StrongChance",&chances[0],0,1,.01,0},{"SpeedyChance",&chances[1],0,1,.01,0},
 {"RegenChance",&chances[2],0,1,.01,0},{"BerserkChance",&chances[3],0,1,.01,0},
 {"EnragedChance",&chances[4],0,1,.01,0},{"HeavyweightChance",&chances[5],0,1,.01,0},
 {"VolatileChance",&chances[6],0,1,.01,0},
 {"RegenPerSecond",&regenRate,0,1,.01,1},{"AffixHPMultiplier",&affixHp,1,100,.1,1},
 {"StrongHPMultiplier",&strongHp,1,100,.1,1},{"StrongDamageMultiplier",&strongPower,.1,10,.1,1},
 {"SpeedyAnimationMultiplier",&speedScale,.1,10,.1,1},{"BerserkDamageMultiplier",&berserkPower,1,10,.1,1},
 {"BerserkHealthThreshold",&berserkThreshold,.01,1,.01,1},
 {"EnragedMaxAnimationMultiplier",&enragedMaxSpeed,1,5,.1,2},
 {"EnragedMaxIncomingDamageMultiplier",&enragedIncoming,1,5,.1,2},
 {"HeavyweightAnimationMultiplier",&heavySpeed,.1,1,.05,2},
 {"VolatileDelaySeconds",&volatileDelay,.25,10,.25,2},
 {"VolatileRadius",&volatileRadius,1,10,.25,2},{"VolatileDamageMultiplier",&volatileDamage,.1,5,.1,2}
};
static HWND panelWindow,panelSliders[7],panelLabels[7],panelHealth;
static int panelPage,panelMap[7];
static void savePanelSetting(const char *key,double value){char text[64];snprintf(text,sizeof(text),"%.4f",value);if(!WritePrivateProfileStringA("Affixes",key,text,iniPath))note("Settings save failed: check INI folder write access.");}
static void refreshPanel(void){
 EnterCriticalSection(&stateLock);int row=0;
 for(unsigned i=0;i<sizeof(panelSettings)/sizeof(panelSettings[0]);i++)if(panelSettings[i].page==panelPage&&row<7){
  PanelSetting*p=&panelSettings[i];panelMap[row]=(int)i;char label[128];snprintf(label,sizeof(label),"%s = %.2f",p->key,*p->value);
  SetWindowTextA(panelLabels[row],label);SendMessageA(panelSliders[row],TBM_SETRANGEMIN,FALSE,0);
  SendMessageA(panelSliders[row],TBM_SETRANGEMAX,FALSE,(LPARAM)lround((p->high-p->low)/p->step));
  SendMessageA(panelSliders[row],TBM_SETPOS,TRUE,(LPARAM)lround((*p->value-p->low)/p->step));
  ShowWindow(panelLabels[row],SW_SHOW);ShowWindow(panelSliders[row],SW_SHOW);row++;
 }
 for(;row<7;row++){panelMap[row]=-1;ShowWindow(panelLabels[row],SW_HIDE);ShowWindow(panelSliders[row],SW_HIDE);}
 SendMessageA(panelHealth,BM_SETCHECK,showHealthNumbers?BST_CHECKED:BST_UNCHECKED,0);LeaveCriticalSection(&stateLock);
}
static void toggleHealthNumbers(void){EnterCriticalSection(&stateLock);showHealthNumbers=!showHealthNumbers;for(State*s=states;s;s=s->next)s->lastLabel=0;int value=showHealthNumbers;LeaveCriticalSection(&stateLock);savePanelSetting("ShowHealthNumbers",value);if(panelHealth)SendMessageA(panelHealth,BM_SETCHECK,value?BST_CHECKED:BST_UNCHECKED,0);}
static LRESULT CALLBACK panelProc(HWND window,UINT message,WPARAM wp,LPARAM lp){
 switch(message){
 case WM_CLOSE:ShowWindow(window,SW_HIDE);return 0;
 case WM_COMMAND:
  if(LOWORD(wp)>=100&&LOWORD(wp)<=102){panelPage=LOWORD(wp)-100;refreshPanel();return 0;}
  if(LOWORD(wp)==103){toggleHealthNumbers();return 0;}break;
 case WM_HSCROLL:
  for(int row=0;row<7;row++)if((HWND)lp==panelSliders[row]&&panelMap[row]>=0){
   PanelSetting*p=&panelSettings[panelMap[row]];LRESULT position=SendMessageA((HWND)lp,TBM_GETPOS,0,0);
   double value=fmin(p->high,fmax(p->low,p->low+position*p->step));
   EnterCriticalSection(&stateLock);*p->value=value;LeaveCriticalSection(&stateLock);savePanelSetting(p->key,value);
   char label[128];snprintf(label,sizeof(label),"%s = %.2f",p->key,value);SetWindowTextA(panelLabels[row],label);return 0;
  }
  break;
 case WM_TIMER:{static int wasF7,wasF8;int f7=(GetAsyncKeyState(VK_F7)&0x8000)!=0,f8=(GetAsyncKeyState(VK_F8)&0x8000)!=0;DWORD process=0;HWND foreground=GetForegroundWindow();GetWindowThreadProcessId(foreground,&process);
  if(process==GetCurrentProcessId()){
   if(f7&&!wasF7)toggleHealthNumbers();
   if(f8&&!wasF8){if(IsWindowVisible(window))ShowWindow(window,SW_HIDE);else{refreshPanel();ShowWindow(window,SW_SHOW);SetForegroundWindow(window);}}
  }wasF7=f7;wasF8=f8;return 0;}
 }return DefWindowProcA(window,message,wp,lp);
}
static DWORD WINAPI settingsPanelThread(void*unused){(void)unused;
 INITCOMMONCONTROLSEX controls={sizeof(controls),ICC_BAR_CLASSES};if(!InitCommonControlsEx(&controls)){note("Settings panel disabled: common controls unavailable.");return 0;}
 WNDCLASSA cls={0};cls.lpfnWndProc=panelProc;cls.hInstance=selfModule;cls.lpszClassName="PirateAffixesSettingsPanel";cls.hCursor=LoadCursorA(NULL,IDC_ARROW);cls.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);
 if(!RegisterClassA(&cls)){note("Settings panel disabled: window registration failed.");return 0;}
 panelWindow=CreateWindowExA(WS_EX_TOPMOST|WS_EX_TOOLWINDOW,cls.lpszClassName,"PirateAffixes - F8 settings / F7 HP numbers",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,80,80,620,650,NULL,NULL,selfModule,NULL);
 if(!panelWindow){note("Settings panel disabled: window creation failed.");return 0;}
 HWND w=panelWindow;
 CreateWindowA("STATIC","Changes save to the INI immediately. HP scales/chances affect NEW enemies.\nOther values update live. This panel does not pause the game.",WS_CHILD|WS_VISIBLE,12,10,590,40,w,NULL,selfModule,NULL);
 const char *pages[]={"Trait chances","Core traits","New traits"};
 for(int i=0;i<3;i++)CreateWindowA("BUTTON",pages[i],WS_CHILD|WS_VISIBLE|WS_TABSTOP,12+i*195,57,185,30,w,(HMENU)(INT_PTR)(100+i),selfModule,NULL);
 panelHealth=CreateWindowA("BUTTON","Show current/max HP numbers (F7)",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,12,95,580,28,w,(HMENU)103,selfModule,NULL);
 for(int row=0;row<7;row++){
  panelLabels[row]=CreateWindowA("STATIC","",WS_CHILD|WS_VISIBLE,12,137+row*65,585,20,w,NULL,selfModule,NULL);
  panelSliders[row]=CreateWindowA(TRACKBAR_CLASSA,"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_AUTOTICKS,12,157+row*65,580,35,w,NULL,selfModule,NULL);
 }
 refreshPanel();SetTimer(w,1,50,NULL);note("Settings ready: F8 native panel, F7 HP numbers. Game focus required.");
 MSG msg;while(GetMessageA(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageA(&msg);}return 0;
}
#endif
