from pathlib import Path
import sys,json,re,struct
r=Path(__file__).parent
sys.path.insert(0,str(r.parent));from ui_reader import Reader
sys.path.insert(0,str(r.parent/'exe'));from analyze import B,rva_off,find_strings
row=Reader(Path('/workspace/scratch/pirate-db/extracted/battle_bomb_info.bin').read_bytes()).table()['rows'][898]
assert row['name']=='boss_skill_barrage_fire'
assert row['values']['particle_id']==25297 and row['values']['init_radius']==3 and row['values']['after_radius']==3
assert row['values']['damage']==300
# Verify native wrapper arguments/factory call, radius DB reads/decoded destinations,
# and copy constructor offsets used for our instance-only overrides.
def code(a,n):return B[rva_off(a):rva_off(a)+n]
assert code(0x5dfdd0,5)==bytes.fromhex('4c8d4c2430')
assert code(0x5dfde4,5)==b'\xe8'+struct.pack('<i',0x62ba50-0x5dfde4-5)
assert code(0x62cb3e,8)==bytes.fromhex('c5fa118560010000') # init radius -> decoded F0
assert code(0x62cb77,8)==bytes.fromhex('c5fa118d64010000') # end radius -> decoded F4
assert code(0x62cb7f,8)==bytes.fromhex('c5fa11855c010000') # current radius -> decoded EC
assert code(0x62bf8c,6)==bytes.fromhex('89857c010000') # damage -> decoded 10C
assert code(0x62da72,5)==b'\xe8'+struct.pack('<i',0x633530-0x62da72-5)
# Modifier bit labels establish super/hard armor 1/2, distinct muteki 0x10.
assert code(0x66b29c,4)==bytes.fromhex('f6473801')
assert code(0x66b2b9,4)==bytes.fromhex('f6473802')
assert code(0x66e1e7,10)==bytes.fromhex('89be0809000089be0c09')
ini=(r/'PirateAffixes.ini').read_text();readme=(r/'README-TEST.txt').read_text();source=(r/'PirateAffixes.c').read_text();panel=(r/'settings_panel.h').read_text()
keys=re.findall(r'^([A-Za-z]+)=',ini,re.M)
assert all('"'+k+'"' in source for k in keys)
positions=[readme.index(k+'=') for k in keys];assert positions==sorted(positions)
assert all('"'+k+'"' in panel for k in keys)
assert 'for(unsigned i=0;i<count;i++)originalRow' not in source
print('0.2.0 checks passed: native blast wrapper, per-instance radius/damage fields, fire particle row, armor bits, INI/parser/panel/documentation parity.')
(r/'build/validation-020.json').write_text(json.dumps({'native_blast_row':898,'native_particle':25297,'stock_radius':3,'configured_default_radius':5,'ini_keys':keys,'native_flags':{'super_armor':1,'hard_armor':2,'invulnerability_not_enabled':16},'in_game_verified':False},indent=2)+'\n')
