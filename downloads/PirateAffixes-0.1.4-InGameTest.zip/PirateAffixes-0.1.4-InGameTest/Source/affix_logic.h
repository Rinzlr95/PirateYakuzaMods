#ifndef AFFIX_LOGIC_H
#define AFFIX_LOGIC_H
#include <stdint.h>
#include <math.h>
enum { AFF_STRONG=1, AFF_SPEEDY=2, AFF_REGEN=4 };
static unsigned aff_roll(const double draws[3],const double chances[3]) { unsigned t=0;for(unsigned i=0;i<3;i++)if(draws[i]<chances[i])t|=1u<<i;return t; }
static unsigned aff_hp_scale(unsigned traits){return (traits&AFF_STRONG)?10u:(traits?5u:1u);}
static unsigned aff_count(unsigned t) {return !!(t&1)+!!(t&2)+!!(t&4);}
static int aff_elite(unsigned t) {return aff_count(t)>=2;}
static int64_t aff_heal(int64_t hp,int64_t max,double dt,double rate,double *credit) {
 if(hp<=0||max<=0||hp>=max){*credit=0;return hp;}
 if(!isfinite(dt)||dt<=0||dt>.25||!isfinite(rate)||rate<0)return hp;
 *credit+=(double)max*rate*dt;int64_t whole=(int64_t)floor(*credit);*credit-=whole;
 if(whole>=max-hp){*credit=0;return max;}return hp+whole;
}
#endif
