#include <assert.h>
#include <stdio.h>
#include "affix_logic.h"
int main(void){
 double chances[]={.2,.2,.2};
 for(unsigned mask=0;mask<8;mask++){double draws[]={(mask&1)?.1:.9,(mask&2)?.1:.9,(mask&4)?.1:.9};assert(aff_roll(draws,chances)==mask);assert(aff_hp_scale(mask)==((mask&1)?10u:mask?5u:1u));assert(aff_elite(mask)==(mask==3||mask==5||mask==6||mask==7));assert(500*aff_count(mask)==(mask==7?1500:mask==3||mask==5||mask==6?1000:mask==0?0:500));}
 double credit=0;int64_t hp=50;for(int i=0;i<60;i++)hp=aff_heal(hp,100,1./60,.01,&credit);assert(hp==51);
 assert(aff_heal(0,100,.25,1,&credit)==0);assert(aff_heal(99,100,.25,1,&credit)==100);assert(aff_heal(50,100,0,1,&credit)==50);assert(aff_heal(50,100,NAN,1,&credit)==50);
 puts("Native core: all 8 trait combinations, money tiers, fractional healing, cap, pause and death checks passed.");return 0;
}
