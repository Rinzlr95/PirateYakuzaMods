#include <assert.h>
#include <stdio.h>
#include "affix_logic.h"
int main(void){
 for(unsigned n=0;n<=4;n++){assert(aff_bonus_cash(50000,n)==(int32_t)(50000*n));assert(aff_bonus_cash(500000,n)==(int32_t)(500000*n));}
 assert(aff_bonus_cash(INT32_MAX,3)==INT32_MAX);
 double chances[]={.2,.2,.2,.1};
 for(unsigned mask=0;mask<16;mask++){
  double draws[]={(mask&1)?.01:.9,(mask&2)?.01:.9,(mask&4)?.01:.9,(mask&8)?.01:.9};
  unsigned count=0;for(unsigned i=0;i<4;i++)count+=(mask>>i)&1;
  assert(aff_roll(draws,chances)==mask);assert(aff_count(mask)==count);assert(aff_elite(mask)==(count>=2));
  assert(aff_hp_scale(mask,2.5,6)==((mask&1)?6:mask?2.5:1));
  assert(aff_bonus_cash(500000,count)==(int32_t)(500000*count));
 }
 assert(aff_power_factor(AFF_BERSERK,50,100,3,2,.5)==1);
 assert(aff_power_factor(AFF_BERSERK,49,100,3,2,.5)==2);
 assert(aff_power_factor(AFF_STRONG|AFF_BERSERK,49,100,3,2,.5)==6);
 assert(aff_power_factor(AFF_STRONG|AFF_BERSERK,51,100,3,2,.5)==3);
 assert(aff_power_factor(AFF_BERSERK,0,100,3,2,.5)==1);
 assert(aff_power_factor(AFF_BERSERK,10,0,3,2,.5)==1);
 assert(aff_initial_hp(2560,25600,23040)==25600);
 assert(aff_initial_hp(2500,25600,23040)==25540); /* preserve concurrent damage */
 assert(aff_initial_hp(0,25600,23040)==0);
 assert(aff_initial_hp(5000,6400,6000)==6400);
 assert(aff_hp_scale(AFF_STRONG|AFF_SPEEDY,7.5,12.5)==12.5);assert(aff_hp_scale(AFF_REGEN,7.5,12.5)==7.5);assert(aff_hp_scale(0,7.5,12.5)==1.);
 double halfCredit=0;assert(aff_heal(1000,6400,.25,.05,&halfCredit)==1080);
 double credit=0;int64_t hp=50;for(int i=0;i<60;i++)hp=aff_heal(hp,100,1./60,.01,&credit);assert(hp==51);
 assert(aff_heal(0,100,.25,1,&credit)==0);assert(aff_heal(99,100,.25,1,&credit)==100);assert(aff_heal(50,100,0,1,&credit)==50);assert(aff_heal(50,100,NAN,1,&credit)==50);
 puts("Native core: all 16 trait combinations, Berserk threshold/stacking/recovery, money tiers, fractional healing, cap, pause and death checks passed.");return 0;
}
