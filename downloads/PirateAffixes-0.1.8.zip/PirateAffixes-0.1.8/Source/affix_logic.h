#ifndef AFFIX_LOGIC_H
#define AFFIX_LOGIC_H
#include <stdint.h>
#include <math.h>
enum { AFF_STRONG=1, AFF_SPEEDY=2, AFF_REGEN=4, AFF_BERSERK=8, AFF_TRAIT_COUNT=4 };
static unsigned aff_roll(const double draws[AFF_TRAIT_COUNT],const double chances[AFF_TRAIT_COUNT]) { unsigned t=0;for(unsigned i=0;i<AFF_TRAIT_COUNT;i++)if(draws[i]<chances[i])t|=1u<<i;return t; }
static int64_t aff_initial_hp(int64_t hp,int64_t max,int64_t bonus){if(hp<=0||max<=0)return hp;if(hp>=max)return max;return bonus>=max-hp?max:hp+bonus;}
static double aff_hp_scale(unsigned traits,double ordinaryAffix,double strong){return (traits&AFF_STRONG)?strong:(traits?ordinaryAffix:1.);}
static double aff_power_factor(unsigned traits,int64_t hp,int64_t max,double strong,double berserk,double threshold){double factor=(traits&AFF_STRONG)?strong:1.;if((traits&AFF_BERSERK)&&hp>0&&max>0&&(double)hp/max<threshold)factor*=berserk;return factor;}
static int32_t aff_bonus_cash(int32_t tableAmount,unsigned count){int64_t total=(int64_t)tableAmount*count;return total>INT32_MAX?INT32_MAX:total<INT32_MIN?INT32_MIN:(int32_t)total;}
static unsigned aff_count(unsigned t) {return !!(t&1)+!!(t&2)+!!(t&4)+!!(t&8);}
static int aff_elite(unsigned t) {return aff_count(t)>=2;}
static int64_t aff_heal(int64_t hp,int64_t max,double dt,double rate,double *credit) {
 if(hp<=0||max<=0||hp>=max){*credit=0;return hp;}
 if(!isfinite(dt)||dt<=0||dt>.25||!isfinite(rate)||rate<0)return hp;
 *credit+=(double)max*rate*dt;int64_t whole=(int64_t)floor(*credit);*credit-=whole;
 if(whole>=max-hp){*credit=0;return max;}return hp+whole;
}
#endif
