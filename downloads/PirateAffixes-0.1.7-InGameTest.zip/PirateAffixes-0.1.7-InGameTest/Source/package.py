from pathlib import Path
import sys,hashlib,zipfile,json
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'exe/python-libs'))
import pefile
r=Path(__file__).resolve().parent;version=sys.argv[1];b=r/'build/PirateAffixes.asi';pe=pefile.PE(str(b));assert pe.FILE_HEADER.Machine==0x8664 and pe.FILE_HEADER.Characteristics&0x2000
imports=[x.dll.decode() for x in pe.DIRECTORY_ENTRY_IMPORT];assert not any('private' in i.lower() for i in imports)
validation={'version':version,'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'in_game_verified':False,'dependencies':imports,'recorded_layout_validation':json.loads((r/'deep-validation.json').read_text())}
extra=r/'build/validation-012.json'
if extra.exists():validation['current_api_checks']=json.loads(extra.read_text())
files={'PirateAffixes.asi':b.read_bytes(),'PirateAffixes.ini':(r/'PirateAffixes.ini').read_bytes(),'README-FIRST.txt':(r/'README-TEST.txt').read_bytes(),'LICENSE-MINHOOK.txt':(r/'minhook/LICENSE.txt').read_bytes(),'VALIDATION.json':(json.dumps(validation,indent=2)+'\n').encode()}
for name in ['PirateAffixes.c','affix_logic.h','affix_logic_tests.c','target_signatures.h','build.sh','validate_deep.py','validate_012.py','package.py']:
 files['Source/'+name]=(r/name).read_bytes()
for p in (r/'minhook').rglob('*'):
 if p.is_file():files['Source/minhook/'+p.relative_to(r/'minhook').as_posix()]=p.read_bytes()
files['MANIFEST.sha256']=''.join(hashlib.sha256(data).hexdigest()+'  '+path+'\n' for path,data in sorted(files.items())).encode()
out=r/'dist'/('PirateAffixes-'+version+'-InGameTest.zip');prefix=out.stem+'/'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path,data in files.items():z.writestr(prefix+path,data)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for path,data in files.items():assert z.read(prefix+path)==data
sha=hashlib.sha256(out.read_bytes()).hexdigest();out.with_suffix('.zip.sha256').write_text(sha+'  '+out.name+'\n');print(json.dumps({'file':str(out),'size':out.stat().st_size,'sha256':sha}))
