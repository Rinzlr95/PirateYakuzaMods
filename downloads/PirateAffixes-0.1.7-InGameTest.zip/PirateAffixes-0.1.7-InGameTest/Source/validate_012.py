from pathlib import Path
import sys,struct,json
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent));from ui_reader import Reader
sys.path.insert(0,str(root.parent/'exe'));from analyze import B,rva_off
base=Reader(Path('/workspace/scratch/pirate-db/extracted/character_npc_soldier_reward_item.bin').read_bytes()).table()['rows']
mod=Reader(Path('/workspace/attachments/b13ea323-abde-4739-8b0f-5dc25358f15a/character_npc_soldier_reward_item.bin').read_bytes()).table()['rows']
assert base[244]['name']==mod[244]['name']=='money_050000'
assert base[244]['values']['money']==50000 and mod[244]['values']['money']==500000
assert base[244]['values']['item']==mod[244]['values']['item']==0
for n in range(1,4):assert base[244]['values']['money']*n/100==500*n and mod[244]['values']['money']*n/100==5000*n
# Verify the stock setup calls the exact typed string assign and name setter
# used by this build. Also verify that the setter targets name child 0x911.
def call_target(a):
 o=rva_off(a);assert B[o]==0xe8;return a+5+struct.unpack_from('<i',B,o+1)[0]
assert call_target(0x8bfc8e)==0x5e64b0
assert call_target(0x8bfc9d)==0x1cc5a60
assert call_target(0x1cc5a93)==0x1782730
assert B[rva_off(0x1cc5a78):rva_off(0x1cc5a78)+6]==bytes.fromhex('41b811090000')
# Confirm the cash constructor receives its amount in edx and saves it.
code=B[rva_off(0x8df800):rva_off(0x8df800)+0x60]
assert bytes.fromhex('89559f') in code
print('0.1.2 checks passed: typed stock HUD-name setter chain; bonus row 244 and x10 table amounts; cash constructor argument.')
(root/'build/validation-012.json').write_text(json.dumps({'original_row_244_units':50000,'uploaded_x10_row_244_units':500000,'display_units_per_dollar_assumption':100,'currency_display_conversion_verified_in_game':False,'ui_name_setter':'0x1CC5A60 -> name child 0x911 -> 0x1782730','stock_call_site':'0x8BFC9D','cash_constructor':'0x8DF800','in_game_validated':False},indent=2)+'\n')
