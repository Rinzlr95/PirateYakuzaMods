from pathlib import Path
import re,struct,json
root=Path(__file__).resolve().parent.parent/'deep-live';report=[];brains=[];flags=[];gauge_links=[];motions=[]
u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
u32=lambda b,o:struct.unpack_from('<I',b,o)[0]
u64=lambda b,o:struct.unpack_from('<Q',b,o)[0]
i64=lambda b,o:struct.unpack_from('<q',b,o)[0]
f32=lambda b,o:struct.unpack_from('<f',b,o)[0]
for p in sorted(root.rglob('sample-*')):
 if not p.is_dir():continue
 segments=[];pool=(p/'handle-table.bin').read_bytes()
 for l in (p/'index.txt').read_text().splitlines():
  m=re.match(r'(.+) address=0x([A-F0-9]+) bytes=(\d+)',l)
  if m:
   f=p/(m[1]+'.bin')
   if f.exists():segments.append((int(m[2],16),f.read_bytes(),f.name))
 def read(a,n):
  ss=[s for s in segments if s[0]<=a and a+n<=s[0]+len(s[1])]
  if not ss:return None
  start,b,_=max(ss,key=lambda s:s[0]);return b[a-start:a-start+n]
 infos={};gauges={};fighters={};actors={}
 for a,b,name in segments:
  if '-ptr-' in name:continue
  if len(b)<48:continue
  vt=u64(b,0)-0x140000000;owner=u32(b,40)
  if vt==0x2b0f100:infos[owner]=(a,b)
  if vt==0x2bed228:gauges[owner]=(a,b)
  if vt in (0x2ad1b88,0x2add378):fighters[owner]=(a,b)
  if re.fullmatch(r'actor-[A-F0-9]+\.bin',name):actors[u32(b,12)]=(a,b)
 for owner,(address,actor) in actors.items():
  motion=u64(actor,0x9f8);mb=read(motion,0x143)
  if mb:
   assert u64(mb,0)==0x142ba8770
   assert all(0<=f32(mb,o)<=20 for o in (0x12c,0x130)) and mb[0x142] in (0,1)
   motions.append(dict(sample=p.name,owner=hex(owner),controller=hex(motion),speed=f32(mb,0x130 if mb[0x142] else 0x12c)))
 for owner,(address,info) in infos.items():
  cached=u32(info,0xc8)
  if owner in gauges:
   target=gauges[owner];assert cached==u32(target[1],12)
   slot=cached&0xfffff;assert u16(pool,slot*32+8)==cached>>20 and u64(pool,slot*32)==target[0]
   assert u16(target[1],36)==74 and u32(target[1],40)==owner
   gauge_links.append(dict(sample=p.name,owner=hex(owner),gauge_uid=hex(cached),gauge=hex(target[0])))
  elif cached==0:assert owner not in gauges
 for owner,(a,b) in fighters.items():
  info=infos.get(owner);g=gauges.get(owner);actor=actors.get(owner);uid=u32(b,12);idx=uid&0xfffff
  assert idx<0x80000 and u16(pool,idx*32+8)==uid>>20 and u64(pool,idx*32)==a and u16(pool,idx*32+12)==4
  assert u64(b,0xd10)==0x142ad1b68
  if actor:assert u32(actor[1],0x4eb8)==uid
  if u32(b,36)!=u16(b,36):flags.append(hex(u32(b,36)))
  hp,maxhp=i64(b,0xd20),i64(b,0xd18);control,cat=u32(b,0xe0),u32(b,0xcfc);skin=u32(g[1],0x74) if g else None
  qualifies=control==3 and cat in(2,3) and info is not None and info[1][0xd0]==0 and skin in(1,3,9) and 0<hp<=maxhp
  report.append(dict(sample=p.name,owner=hex(owner),hp=hp,max_hp=maxhp,control=control,category=cat,skin=skin,qualifies=qualifies,header_type_low16=u16(b,36)))
  brain=u64(b,0x9b0);bb=read(brain,0x880) if brain else None
  if bb and u64(bb,0)==0x142ad5b58:
   assert u32(bb,0x868)==owner and u64(bb,0x798)==brain
   speeds=[f32(bb,o) for o in [0x5c4,0x584,0x5c8]];assert all(0<x<=20 for x in speeds)
   brains.append(dict(sample=p.name,owner=hex(owner),brain=hex(brain),motion=speeds[0],shift=speeds[1],wait_shift=speeds[2],ai_setting=u32(bb,0x560)))
assert len(brains)>=2 and any(r['qualifies'] for r in report)
assert all(not r['qualifies'] for r in report if r['control']==2 or r['hp']<=0)
assert flags, 'Capture must exercise packed header flags'
assert len(gauge_links)>=6, 'Gauge-link regression needs recorded enemy examples'
assert len(motions)>=9
result=dict(validated_motion_controllers=motions,actors=report,validated_brains=brains,packed_header_examples=flags,validated_gauge_links=gauge_links)
Path(__file__).with_name('deep-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('Deep replay passed:',len(report),'combat objects;',len(brains),'AI objects with owner/self links and speed values; packed type flags handled; player/dead actors excluded.')
print('Validated cached soldier-info to gauge links:',len(gauge_links))
