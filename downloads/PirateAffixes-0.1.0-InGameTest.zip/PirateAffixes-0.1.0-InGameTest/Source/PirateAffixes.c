#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "minhook/include/MinHook.h"
#include "affix_logic.h"
// Steam 1.14 only. Addresses are RVAs, validated against the supplied executable.
#define REGISTRY 0x3885E40ull
#define INFO_VT 0x2B0F100ull
#define FIGHTER_VT 0x2AD1B88ull
#define GAUGE_VT 0x2BED228ull
#define BRAIN_VT 0x2AD5B58ull
#define HEALTH_VT 0x2AD1B68ull
#define STRONG_POWER 1.5f
#define STRONG_HP 1.25
#define SPEED_SCALE 1.25f
static uintptr_t image;
static HMODULE selfModule;
static CRITICAL_SECTION stateLock;
static DWORD tlsIndex=TLS_OUT_OF_INDEXES;
static double chances[3]={.2,.2,.2},regenRate=.01;
static FILE *logFile;
static unsigned long spawnCount;
static LARGE_INTEGER qpcFrequency;
static volatile LONG ready;
static char iniPath[MAX_PATH],logPath[MAX_PATH];
typedef struct State State;
struct State {State *next;uint32_t owner,infoId,fighterId;uintptr_t info,fighter,brain;unsigned traits;int applied,paid,refs,speedLogged,regenLogged,boss;uint32_t aiId;float motion,shift,wait;float writtenMotion,writtenShift,writtenWait;double credit;LONGLONG lastRegen;char *label;};
static State *states;
typedef void (__fastcall *TickFn)(void*);
typedef void* (__fastcall *NameFn)(void*,void*);
typedef void (__fastcall *DefeatFn)(void*,const void*);
typedef void (__fastcall *RowFn)(void*,const void*,uint32_t);
typedef void* (__fastcall *GetInfoFn)(void*,uint32_t*);
typedef void* (__fastcall *GetComponentFn)(void*,uint32_t*,uint32_t);
static TickFn originalTick;
static NameFn originalName;
static DefeatFn originalDefeat;
static RowFn originalRow;
static GetInfoFn getInfo;
static GetComponentFn getComponent;
typedef struct Scope {struct Scope *previous;State *state;int item,money;} Scope;
static int readmem(uintptr_t p,void *out,SIZE_T n) {SIZE_T got=0;return p>=65536&&ReadProcessMemory(GetCurrentProcess(),(void*)p,out,n,&got)&&got==n;}
static uint32_t u32(uintptr_t p){uint32_t v=0;readmem(p,&v,4);return v;}
static uintptr_t ptr(uintptr_t p){uintptr_t v=0;readmem(p,&v,8);return v;}
static int64_t i64(uintptr_t p){int64_t v=0;readmem(p,&v,8);return v;}
static float f32(uintptr_t p){float v=NAN;readmem(p,&v,4);return v;}
static void note(const char *s){if(logFile){fprintf(logFile,"%s\n",s);fflush(logFile);}}
static uintptr_t resolve(uint32_t uid,uint16_t kind){uint32_t index=uid&0xfffff;unsigned char row[32];if(!uid||index>=0x80000||!readmem(image+REGISTRY+(uintptr_t)index*32,row,32))return 0;uint16_t gen,k;memcpy(&gen,row+8,2);memcpy(&k,row+12,2);uintptr_t address;memcpy(&address,row,8);if(gen!=(uid>>20)||k!=kind||u32(address+12)!=uid)return 0;return address;}
static int component(uintptr_t p,uintptr_t vt,uint32_t owner,uint16_t type){unsigned char b[48];uint64_t v;uint32_t o;uint16_t t;if(!readmem(p,b,48))return 0;memcpy(&v,b,8);memcpy(&t,b+36,2);memcpy(&o,b+40,4);return v==image+vt&&t==type&&o==owner&&resolve(u32(p+12),4)==p;}
static uintptr_t infoFor(uintptr_t actor,uint32_t owner){uint32_t uid=0;getInfo((void*)(actor+0x68),&uid);uintptr_t info=resolve(uid,4);return component(info,INFO_VT,owner,68)?info:0;}
static uintptr_t gaugeFor(uintptr_t actor,uint32_t owner){uint32_t uid=0;getComponent((void*)actor,&uid,74);uintptr_t g=resolve(uid,4);return component(g,GAUGE_VT,owner,74)?g:0;}
static State *findState(uint32_t owner,uint32_t infoId,uint32_t fighterId){for(State*s=states;s;s=s->next)if(s->owner==owner&&s->infoId==infoId&&s->fighterId==fighterId)return s;return NULL;}
// Caller holds stateLock. No template/name/location whitelist is used.
static State *ensure(uint32_t owner,uintptr_t info,uintptr_t gauge,int allowDead){
 uintptr_t actor=resolve(owner,3);if(!actor||!component(info,INFO_VT,owner,68))return NULL;
 uintptr_t fighter=resolve(u32(actor+0x4EB8),4);if(!component(fighter,FIGHTER_VT,owner,70)||ptr(fighter+0xD10)!=image+HEALTH_VT)return NULL;
 uint32_t control=u32(fighter+0xE0),category=u32(fighter+0xCFC);unsigned char force=255;readmem(info+0xD0,&force,1);
 if(control!=3||(category!=2&&category!=3)||force!=0)return NULL;
 uint32_t infoId=u32(info+12),fighterId=u32(fighter+12);State*s=findState(owner,infoId,fighterId);if(s){if(!allowDead&&i64(fighter+0xD20)<=0)return NULL;return s;}
 if(!gauge)return NULL;uint32_t skin=u32(gauge+0x74);if(skin!=1&&skin!=3&&skin!=9)return NULL;
 int64_t hp=i64(fighter+0xD20),max=i64(fighter+0xD18);if(max<=0||hp>max||(!allowDead&&hp<=0))return NULL;
 if(hp<=0)return NULL;
 if((spawnCount&31)==0){State **link=&states;while(*link){State *old=*link;if(!old->refs&&(resolve(old->owner,3)==0||resolve(old->infoId,4)!=old->info||resolve(old->fighterId,4)!=old->fighter)){*link=old->next;/* Immutable name buffers remain alive until process exit. */free(old);}else link=&old->next;}}
 s=calloc(1,sizeof(*s));if(!s)return NULL;double draws[3];uint32_t random[3];if(BCryptGenRandom(NULL,(PUCHAR)random,sizeof(random),BCRYPT_USE_SYSTEM_PREFERRED_RNG)!=0){free(s);return NULL;}
 for(int i=0;i<3;i++)draws[i]=random[i]/4294967296.0;s->traits=aff_roll(draws,chances);s->boss=category==3||skin==3||skin==9;s->owner=owner;s->infoId=infoId;s->fighterId=fighterId;s->info=info;s->fighter=fighter;s->aiId=UINT32_MAX;s->next=states;states=s;
 if(logFile){fprintf(logFile,"spawn %lu owner=%08X template=%u traits=%u elite=%d hp=%lld/%lld\n",++spawnCount,owner,u32(info+0x74),s->traits,aff_elite(s->traits),(long long)hp,(long long)max);fflush(logFile);}return s;
}
static int stillValid(State*s){return resolve(s->owner,3)&&resolve(s->infoId,4)==s->info&&resolve(s->fighterId,4)==s->fighter&&ptr(s->fighter+0xD10)==image+HEALTH_VT;}
static void applyFloat(uintptr_t address,float baseline,float scale,float *last){float current=f32(address);if(!isfinite(current)||current<=0||current>20)return;if(*last>0&&current==*last)return;float v=baseline*scale;SIZE_T done;if(isfinite(v)&&v>0&&v<=25&&WriteProcessMemory(GetCurrentProcess(),(void*)address,&v,4,&done)&&done==4)*last=v;}
static void apply(State*s,int gameplayTick){
 if(!stillValid(s))return;uintptr_t fighter=s->fighter;
 if(!s->applied){
  if(s->traits&AFF_STRONG){float power=f32(s->info+0xB0),written=0;if(isfinite(power)&&power>0&&power<100)applyFloat(s->info+0xB0,power,STRONG_POWER,&written);
   int64_t oldMax=i64(fighter+0xD18),oldHp=i64(fighter+0xD20);if(oldMax>0&&oldMax<1000000000&&oldHp>0&&oldHp<=oldMax){int64_t newMax=(int64_t)floor(oldMax*STRONG_HP),newHp=(int64_t)floor((double)oldHp/oldMax*newMax);if(InterlockedCompareExchange64((volatile LONG64*)(fighter+0xD18),newMax,oldMax)==oldMax)InterlockedCompareExchange64((volatile LONG64*)(fighter+0xD20),newHp,oldHp);}
  }s->applied=1;
 }
 if(s->traits&AFF_SPEEDY){uintptr_t brain=ptr(fighter+0x9B0);if(brain&&ptr(brain)==image+BRAIN_VT&&u32(brain+0x868)==s->owner&&ptr(brain+0x798)==brain){
   uint32_t ai=u32(brain+0x560);if(s->brain!=brain){s->brain=brain;s->writtenMotion=s->writtenShift=s->writtenWait=0;}s->aiId=ai;if(!s->speedLogged&&logFile){fprintf(logFile,"speed owner=%08X brain=%p motion_before=%.5f shift_before=%.5f wait_before=%.5f\n",s->owner,(void*)brain,f32(brain+0x5C4),f32(brain+0x584),f32(brain+0x5C8));fflush(logFile);s->speedLogged=1;}
   float m=f32(brain+0x5C4),v=f32(brain+0x584),w=f32(brain+0x5C8);
   if(m!=s->writtenMotion){s->motion=m;applyFloat(brain+0x5C4,m,SPEED_SCALE,&s->writtenMotion);}if(v!=s->writtenShift){s->shift=v;applyFloat(brain+0x584,v,SPEED_SCALE,&s->writtenShift);}if(w!=s->writtenWait){s->wait=w;applyFloat(brain+0x5C8,w,SPEED_SCALE,&s->writtenWait);}
  }}
 if(gameplayTick&&(s->traits&AFF_REGEN)){float dt=f32(image+0x4885E44);LARGE_INTEGER now;QueryPerformanceCounter(&now);double elapsed=s->lastRegen?(double)(now.QuadPart-s->lastRegen)/qpcFrequency.QuadPart:0;
  if(!s->regenLogged&&logFile){fprintf(logFile,"regen owner=%08X first_game_delta=%.8f rate=%.5f\n",s->owner,dt,regenRate);fflush(logFile);s->regenLogged=1;}if(!s->lastRegen){s->lastRegen=now.QuadPart;return;}if(!isfinite(dt)||dt<=0||dt>.25){s->lastRegen=now.QuadPart;return;}if(elapsed<dt*.5)return;s->lastRegen=now.QuadPart;
  int64_t hp=i64(fighter+0xD20),max=i64(fighter+0xD18);double credit=s->credit;int64_t healed=aff_heal(hp,max,dt,regenRate,&credit);if(healed==hp||InterlockedCompareExchange64((volatile LONG64*)(fighter+0xD20),healed,hp)==hp)s->credit=credit;
 }
}
static void __fastcall hookTick(void *gauge){
 if(ready){uintptr_t g=(uintptr_t)gauge;uint32_t owner=u32(g+40);uintptr_t actor=resolve(owner,3);if(actor&&component(g,GAUGE_VT,owner,74)){uintptr_t info=infoFor(actor,owner);EnterCriticalSection(&stateLock);State*s=ensure(owner,info,g,0);if(s)apply(s,1);LeaveCriticalSection(&stateLock);}}
 originalTick(gauge);
}
static void* __fastcall hookName(void *info,void *output){
 void*result=originalName(info,output);if(!ready||!result)return result;uintptr_t p=(uintptr_t)info;uint32_t owner=u32(p+40);uintptr_t actor=resolve(owner,3),g=actor?gaugeFor(actor,owner):0;EnterCriticalSection(&stateLock);State*s=ensure(owner,p,g,0);
 if(s&&s->traits){apply(s,0);if(!s->label){char original[512];const char*name=(const char*)ptr((uintptr_t)result);size_t n=0;for(;n<sizeof(original)-1;n++){if(!readmem((uintptr_t)name+n,original+n,1)||original[n]==0)break;}original[n]=0;char label[1024];snprintf(label,sizeof(label),"%s [%s%s%s%s]",original,aff_elite(s->traits)?"<color=clan_battle_log_enemy>Elite</color> ":"",(s->traits&AFF_STRONG)?"<color=striking>Strong</color> ":"",(s->traits&AFF_SPEEDY)?"<color=batting_pitch_light_blue>Speedy</color> ":"",(s->traits&AFF_REGEN)?"<color=batting_pitch_green>Regen</color>":"");size_t bytes=strlen(label)+1;s->label=calloc(1,bytes+32);if(s->label)memcpy(s->label,label,bytes);}if(s->label){SIZE_T wrote;uintptr_t label=(uintptr_t)s->label;WriteProcessMemory(GetCurrentProcess(),result,&label,8,&wrote);}}
 LeaveCriticalSection(&stateLock);return result;
}
static int itemRow(uint32_t row){return row>=252&&row<=260;}
static int moneyRow(uint32_t row){return row==9||row==10||(row>=233&&row<=251)||(row>=261&&row<=265);}
static void __fastcall hookRow(void *context,const void *position,uint32_t row){Scope*scope=TlsGetValue(tlsIndex);if(scope&&u32((uintptr_t)context+40)==scope->state->owner){if(itemRow(row))scope->item=1;if(moneyRow(row))scope->money=1;}originalRow(context,position,row);}
static void __fastcall hookDefeat(void *context,const void *position){
 if(!ready){originalDefeat(context,position);return;}uintptr_t ctx=(uintptr_t)context;uint32_t owner=u32(ctx+40);uintptr_t actor=resolve(owner,3),info=actor?infoFor(actor,owner):0,g=actor?gaugeFor(actor,owner):0;
 EnterCriticalSection(&stateLock);State*s=ensure(owner,info,g,1);if(s&&s->paid)s=NULL;if(s){s->paid=1;s->refs++;}LeaveCriticalSection(&stateLock);if(!s){originalDefeat(context,position);return;}
 Scope scope={(Scope*)TlsGetValue(tlsIndex),s,0,0};TlsSetValue(tlsIndex,&scope);originalDefeat(context,position);
 unsigned char pending=0;readmem(ctx+0x8C,&pending,1);uint32_t planned=u32(ctx+0x88);if(pending){if(itemRow(planned))scope.item=1;if(moneyRow(planned)||(planned==0&&i64(ctx+0x80)>0))scope.money=1;}
 int originalItem=scope.item,originalMoney=scope.money;unsigned count=aff_count(s->traits);for(unsigned i=0;i<count;i++)originalRow(context,position,10); // Existing $500 row: the installed money mod supplies its own value.
 if(count)scope.money=1;int guarantee=aff_elite(s->traits)||s->boss;
 if(guarantee&&!scope.item)originalRow(context,position,252); // One existing level-1 medicine if the original roll supplied no item.
 if(guarantee&&!scope.money)originalRow(context,position,9); // Existing smallest active cash row; preserves installed table value.
 TlsSetValue(tlsIndex,scope.previous);if(logFile){EnterCriticalSection(&stateLock);fprintf(logFile,"defeat owner=%08X traits=%u base_bonus=%u guarantee=%d original_item=%d original_money=%d\n",owner,s->traits,500*count,guarantee,originalItem,originalMoney);fflush(logFile);LeaveCriticalSection(&stateLock);}EnterCriticalSection(&stateLock);s->refs--;LeaveCriticalSection(&stateLock);
}
#include "target_signatures.h"
static int fingerprint(void){char path[MAX_PATH];if(!GetModuleFileNameA(NULL,path,MAX_PATH))return 0;HANDLE f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return 0;HCRYPTPROV provider=0;HCRYPTHASH hash=0;int ok=0;if(!CryptAcquireContextA(&provider,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT)||!CryptCreateHash(provider,CALG_MD5,0,0,&hash))goto done;BYTE buffer[65536],digest[16];DWORD count,size=16;while(ReadFile(f,buffer,sizeof(buffer),&count,NULL)&&count)if(!CryptHashData(hash,buffer,count,0))goto done;if(!CryptGetHashParam(hash,HP_HASHVAL,digest,&size,0))goto done;const BYTE expected[]={0xD4,0xAA,0x28,0x9C,0xF4,0x29,0x4F,0x50,0x7B,0xF2,0x0D,0x3C,0xE2,0xFA,0xEB,0x16};ok=memcmp(digest,expected,16)==0;done:if(hash)CryptDestroyHash(hash);if(provider)CryptReleaseContext(provider,0);CloseHandle(f);return ok;}
static double setting(const char*key,double fallback){char text[64],def[64];snprintf(def,sizeof(def),"%.8f",fallback);GetPrivateProfileStringA("Affixes",key,def,text,sizeof(text),iniPath);char *end;double v=strtod(text,&end);return end!=text&&isfinite(v)&&v>=0&&v<=1?v:fallback;}
static DWORD WINAPI initialize(void *unused){(void)unused;char path[MAX_PATH];GetModuleFileNameA(selfModule,path,MAX_PATH);char *end=NULL;for(char *c=path;*c;c++)if(*c=='\\')end=c;if(end)*end=0;snprintf(iniPath,sizeof(iniPath),"%s\\PirateAffixes.ini",path);snprintf(logPath,sizeof(logPath),"%s\\PirateAffixes.log",path);logFile=fopen(logPath,"a");note("PirateAffixes native prototype initializing. Runtime behavior requires in-game validation.");if(!fingerprint()){note("Disabled: executable MD5 differs from the supported Steam 1.14 build.");return 0;}
 image=(uintptr_t)GetModuleHandleA(NULL);InitializeCriticalSection(&stateLock);QueryPerformanceFrequency(&qpcFrequency);tlsIndex=TlsAlloc();if(tlsIndex==TLS_OUT_OF_INDEXES){note("Disabled: TLS allocation failed.");return 0;}
 chances[0]=setting("StrongChance",.2);chances[1]=setting("SpeedyChance",.2);chances[2]=setting("RegenChance",.2);regenRate=setting("RegenPerSecond",.01);getInfo=(GetInfoFn)(image+0x6750A0);getComponent=(GetComponentFn)(image+0x27CC690);
 unsigned char expectedName[]={0x40,0x53,0x48,0x83,0xEC,0x20},actual[6];if(!readmem(image+0x8BE080,actual,6)||memcmp(actual,expectedName,6)){note("Disabled: name function bytes differ.");return 0;}
 if(!validateTargets())return 0;
 if(MH_Initialize()!=MH_OK||MH_CreateHook((void*)(image+0x1CC8B10),hookTick,(void**)&originalTick)!=MH_OK||MH_CreateHook((void*)(image+0x8BE080),hookName,(void**)&originalName)!=MH_OK||MH_CreateHook((void*)(image+0x8DE7A0),hookDefeat,(void**)&originalDefeat)!=MH_OK||MH_CreateHook((void*)(image+0x8DED80),hookRow,(void**)&originalRow)!=MH_OK){note("Disabled: hook creation failed; no hooks enabled.");return 0;}
 InterlockedExchange(&ready,1);if(MH_EnableHook(MH_ALL_HOOKS)!=MH_OK){InterlockedExchange(&ready,0);MH_DisableHook(MH_ALL_HOOKS);note("Disabled: enabling hooks failed.");return 0;}note("Hooks enabled: fresh per-actor rolls, Strong/Speedy/Regen, name labels and defeat rewards. Await in-game validation.");return 0;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID reserved){(void)reserved;if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);HANDLE thread=CreateThread(NULL,0,initialize,NULL,0,NULL);if(thread)CloseHandle(thread);}return TRUE;}
