PirateAffixes 0.1.1 - IN-GAME TEST BUILD

This is a compiled native ASI prototype, not a confirmed stable release.
Native logic tests, recorded memory-layout checks and PE dependency checks pass.
The DLL has not been executed inside the game in this environment. Live hook
behavior, labels, regeneration while paused, rewards and all boss variants
still require in-game testing. Do not treat compilation as proof they work.

CHANGES IN 0.1.1
Corrected the enemy gauge lookup used by name and defeat hooks. The old
component helper was called with an actor object despite expecting a component.
The corrected lookup follows the soldier-info gauge handle at +0xC8, validated
against six recorded enemy objects. Added first-call hook logs and filter
rejection diagnostics to distinguish loading, hook and qualification failures.
This correction has not yet been confirmed in game.

SUPPORTED BUILD
Like a Dragon: Pirate Yakuza in Hawaii, Windows Steam 1.14.
Executable MD5: D4AA289CF4294F507BF20D3CE2FAEB16.
Other versions disable themselves and record the reason in PirateAffixes.log.
A changed hook target also disables this prototype before hooks are enabled.
English names/text were used for the name-display tests.

INSTALL
1. Close the game. Keep all previous affix/name/stat prototypes disabled in SRMM.
2. Keep your existing x10 money mod enabled.
3. Copy PirateAffixes.asi and PirateAffixes.ini next to likeadragonpirates.exe
   and the existing YakuzaParless.asi in runtime\media.
4. Leave dinput8.dll and YakuzaParless.asi unchanged. Your existing ASI loader
   must load this new ASI. This native prototype is not an SRMM checkbox mod.
5. Start the game, load your save and try a few ordinary street fights.

TRAITS IMPLEMENTED
Each eligible hostile combat actor gets three fresh independent 20% rolls.
Assignment is by runtime actor/component identity, not enemy name, template,
map district or a preselected name list. Ordinary enemies are expected.
Strong: power ratio x1.5 and maximum HP x1.25, preserving current HP percentage.
Speedy: per-actor AI animation, shift movement and waiting shift speed x1.25.
Regen: 1% maximum HP per engine game second, capped at maximum, no resurrection.
Two or three traits add a purple Elite title. Strong is orange, Speedy blue,
Regen green. The label hook retains the original name and adds no TEST text.
Qualification includes enemy and boss/miniboss gauges; the captured player,
friendly force and proxy controller layouts are excluded. Coverage of all
scripted boss layouts has not been established by the available samples.

REWARDS IMPLEMENTED
The defeat hook attempts one existing $500 reward-table entry per trait,
once per actor defeat. In your uploaded x10 table this same entry is $5,000,
so one/two/three traits should add $5,000/$10,000/$15,000 respectively.
No extra multiplication is applied and no reward database file is replaced.
Elite enemies and bosses/minibosses retain the game's original reward roll.
If that roll supplies no item, the prototype attempts one existing level-1
STA medicine reward (item_medicine_STA_lv1, item ID 3292).
If it supplies no money and there is no trait bonus, it attempts the existing
money_0300 entry (base $300; your x10 table supplies $3,000).
Existing scheduled/deferred item and money rewards are counted to avoid
adding fallback rewards when a normal reward is already pending.
These are ground loot attempts through native game functions, not direct
inventory grants. Successful pickup behavior has not yet been tested.

FIRST TEST / TROUBLESHOOTING
PirateAffixes.log is written beside the ASI. Check for "Hooks enabled".
The log records actor IDs, template IDs, trait masks, AI settings and defeat
bonus attempts. Masks: 0=ordinary, 1=Strong, 2=Speedy, 4=Regen; sums combine.
Report whether gameplay loads, names show matching traits, Speedy is faster,
Regen heals during play but stops in menus, and trait cash can be collected.
If startup fails, close the game and rename PirateAffixes.asi to
PirateAffixes.asi.disabled. Disabling an SRMM prototype will not disable this ASI.
Send PirateAffixes.log and PirateAffixes.ini for diagnosis. No more generic
memory snapshots are required for this first test.

REMOVE
Close the game and remove or rename PirateAffixes.asi. The INI and log can
also be removed. No original game archive or save file is edited by this mod.
Per-enemy name buffers are retained until game exit so returned name pointers
cannot dangle; runtime identity records are cleaned when their owners expire.

CREDITS
Thanks to the ShinRyuModManager, Parless and community modding-tool developers.
MinHook by Tsuda Kageyu supplies the native hook mechanism; its license and
source are included. Thanks to you for the captures and in-game name testing.
Reference: https://github.com/Fronkln/DragonEngine.NET (reference only; not a
runtime dependency or a claim of Pirate Yakuza compatibility).
